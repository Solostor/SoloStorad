document.addEventListener("DOMContentLoaded", function() {
  const slides = document.querySelectorAll('.slide-show img');
  let currentSlide = 0;

  function changeSlide() {
    slides[currentSlide].style.opacity = 0;
    currentSlide = (currentSlide + 1) % slides.length;
    slides[currentSlide].style.opacity = 1;
  }

  setInterval(changeSlide, 3000);

  // تنفيذ تسجيل الدخول (placeholder فقط)
  document.getElementById("loginForm").addEventListener("submit", function(e) {
    e.preventDefault();
    alert("تم تسجيل الدخول بنجاح!");
  });
});